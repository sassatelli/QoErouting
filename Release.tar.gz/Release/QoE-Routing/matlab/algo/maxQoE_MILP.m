function [sol] = maxQoE_MILP(matNet, pathInfo, videoInfo, dmdVect_transport)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    tic
    %Variables are [x_dp, u_d], with this index order (see report)
    L = size(pathInfo.bin_edgesInPath,1);
    N = size(pathInfo.bin_initNodes,1);
    P = size(pathInfo.bin_edgesInPath,2);
    D = size(dmdVect_transport,1);
    
    %%%% WARNING UNITS %%%% 
    %Retriveing edge capacities and delays
    if size(matNet.bwVect,1)==L
        capacity_e = matNet.bwVect;%kbps
    else
        capacity_e = [matNet.bwVect;matNet.bwVect];
    end
        
    %%% from matrix matNet.Delay we compute a edge delay vector
%     [rows,cols,vals] = find(matNet.Delay); %ms
%     delay_e = sortrows([rows,cols,vals],[1 2]);
    alpha_p = computeAlpha(matNet.delayVect, pathInfo.bin_edgesInPath);
    
    % order of dec. variables: [x_dp, z_dp, u_d], z_dp is the integer
    % variable
    %Building  ctrs
    A_cap_ctr = sparse(L,D*P+D*P+D);
    
    A_lin_ctr = sparse(0,D*P+D*P+D);
    b_lin_ctr = sparse(0,1);
    
    A_bound_ctr = sparse(0,D*P+D*P+D);
    b_minrate_ctr = zeros(D,1);
    b_maxrate = zeros(D,1);
    
    A_xz_relation_ctr = sparse(D*P,D*P+D*P+D);
    b_xz_relation_ctr = zeros(D*P,1);
    
    A_z_unicity_ctr = sparse(D,D*P+D*P+D);
    b_z_unicity_ctr = ones(D,1);
    
    for d_id = 1:D
        u_d = sparse(1,d_id,1,1,D,1);% vector representing var u_d
        src = dmdVect_transport(d_id,4);
        dst = dmdVect_transport(d_id,5);
        content = dmdVect_transport(d_id,6); %content type 
        resol = dmdVect_transport(d_id,7); % resolution 
        policy = dmdVect_transport(d_id,8); % HAS adaptation
        ij = (src-1)*N + dst;
        
        b_minrate_ctr(d_id) = videoInfo(content,resol,policy).minrate;
        b_maxrate(d_id) = videoInfo(content,resol,policy).maxrate;
        bin_ind=videoInfo(content,resol,policy).pieces(:,1)|videoInfo(content,resol,policy).pieces(:,2);
        %lin_slope = nonzeros(videoInfo(content,resol,policy).pieces(:,1));
        %lin_y_intercept = nonzeros(videoInfo(content,resol,policy).pieces(:,2));
	lin_slope = videoInfo(content,resol,policy).pieces(logical(bin_ind),1);
        lin_y_intercept = videoInfo(content,resol,policy).pieces(logical(bin_ind),2);
        numPieces = numel(lin_slope);
        if not(numel(lin_slope)==numel(lin_y_intercept)), error('not(numel(lin_slope)==numel(lin_y_intercept))'); end
        A_cap_ctr(:,(d_id-1)*P+1 : (d_id-1)*P+P) = kron(ones(L,1),pathInfo.bin_nodePairs(ij,:)).*pathInfo.bin_edgesInPath;
        A_lin_ctr = [A_lin_ctr; -kron(lin_slope,kron(u_d, alpha_p.*pathInfo.bin_nodePairs(ij,:))), sparse(numPieces,D*P), kron(ones(numPieces,1),u_d)];%% we add numPieces for each demand d 
        b_lin_ctr = [b_lin_ctr; lin_y_intercept];
        A_bound_ctr = [A_bound_ctr; kron(u_d, alpha_p.*pathInfo.bin_nodePairs(ij,:)) sparse(1,D*P+D)];
        
    end
    A_xz_relation_ctr = [kron(speye(D,D),spdiags(alpha_p',0,P,P)), -kron(spdiags(b_maxrate,0,D,D),speye(P,P)), sparse(D*P,D)];
    A_z_unicity_ctr = [sparse(D,D*P), kron(speye(D,D),ones(1,P)), sparse(D,D)];
    
    A = [A_cap_ctr;
        %    kron(ones(1,D),pathInfo.bin_edgesInPath), sparse(L,D); % capacity ctrs
        A_lin_ctr;  % linearization ctrs
        A_bound_ctr;
        A_xz_relation_ctr;
        A_z_unicity_ctr
        ]; % min and max rate ctrs
    
    A1 = sparse([-capacity_e; zeros(size(A,1)-L,1)]);
    A = [A, A1];
    ctype_x_dp  = repmat('C', 1, D*P);
    ctype_z_dp  = repmat('B', 1, D*P);
    ctype_u_d   = repmat('C', 1, D);
    ctype_gamma = 'C';
    
    BigM = 2*D + 1;
    obj = [sparse(2*D*P,1); ones(D,1); -BigM];
    %x_dp_ub = ones(1,D*P); x_dp_ub
    ub = [inf(1,D*P),ones(1,D*P),ones(1,D),Inf]';
    lb = zeros(size(ub,1),1);

    rhs = [capacity_e;
            b_lin_ctr;
            b_maxrate;
            b_xz_relation_ctr;
            b_z_unicity_ctr
           ];
    lhs = [-Inf.*ones(L,1); %zeros(L,1); OLD without extra-capacity
            -inf(size(b_lin_ctr,1),1);
            b_minrate_ctr
            -inf(size(b_xz_relation_ctr,1),1);
            b_z_unicity_ctr
           ];
% % 
%       size(A)
%       size(obj)
%       size(lb)
%       size(ub)
%       size(lhs)
%       size(rhs)

    cplex = Cplex('QoE');
    cplex.Model.sense = 'maximize';
    cplex.Model.obj   = obj;
    cplex.Model.lb    = lb;
    cplex.Model.ub    = ub;
    cplex.Model.A     = A;
    cplex.Model.lhs   = full(lhs);
    cplex.Model.rhs   = full(rhs);
    cplex.Model.ctype = [ctype_x_dp ctype_z_dp ctype_u_d ctype_gamma];
    [cplex_opt_gap, cplex_time_limit] = read_opt_gap();
    cplex.Param.mip.tolerances.mipgap.Cur = cplex_opt_gap;
    cplex.Param.timelimit.Cur = cplex_time_limit;
    
    cplex.solve();

    %       cplex.Solution
    
    sol.status = cplex.Solution.status;
    sol.statusstring = cplex.Solution.statusstring;
    sol.time = toc;
    sol.cplex_time = cplex.Solution.time;
    if ((sol.status == 101) || (sol.status == 102))
        % Feasible and optimal solution
        sol.QoE = obj(D*P+D*P+1:D*P+D*P+D)'*cplex.Solution.x(D*P+D*P+1:D*P+D*P+D); %cplex.Solution.objval;
        sol.x_dp_opt = cplex.Solution.x(1:D*P);
        sol.z_dp_opt = cplex.Solution.x(D*P+1:D*P+D*P);
        sol.u_d_opt = cplex.Solution.x(2*D*P+1:end);
        sol.throughput_d = A_bound_ctr*cplex.Solution.x(1:end-1);
        %    sol.Ax = A_lin_ctr(:,1:D*P)*sol.x_dp_opt;
        %    sol.Au = A_lin_ctr(:,D*P+1:end)*sol.u_d_opt;
        %      sol.dif_qoe_dk = b_lin_ctr - A_lin_ctr*cplex.Solution.x;
        %      sol.b_dk = b_lin_ctr;
        %     sol.b_dk_estim = A_lin_ctr*cplex.Solution.x;
        sol.linkLoad_e =A(1:L,:)*cplex.Solution.x;
        sol.x_dp_table = vct2mat(sol.x_dp_opt,D,P);
        sol.z_dp_table = vct2mat(sol.z_dp_opt,D,P);
        sol.countPath_d = sum(sol.x_dp_table>1e-9,2);
        sol.gamma = cplex.Solution.x(D*P+D*P+D+1);
    end
    sol.alpha_p = alpha_p;
    
    %       [b_minrate_ctr sol.throughput_d b_maxrate_ctr]
    %       pause
    
end
function vector_col = mat2vct(matrix)
    vector_col = reshape(matrix', [numel(matrix) 1]);
end
function matrix = vct2mat(vector, numRows, numCols)
    matrix = (reshape(vector,[numCols numRows]))';
end
function alpha_p= computeAlpha(delay_e, bin_edgesInPath)
    %load('cubic/cubicThrp_vs_delay','avg_coeffs') it's for the range
    % 20-180ms
    % delay in ms
    avg_coeffs_cubicThrp_vs_delay = [-0.00127870740156237,1.00108375856055]; %slope, y-intercept
    thrp_vs_delay_slope = avg_coeffs_cubicThrp_vs_delay(1);
    thrp_vs_delay_y_intcpt = avg_coeffs_cubicThrp_vs_delay(2);      
    delay_p = delay_e'*bin_edgesInPath; %path delay
    alpha_p = (thrp_vs_delay_y_intcpt + thrp_vs_delay_slope*delay_p);
    
    %negative alphas_p do not make sense. Ideally, their associated paths
    % should be removed from the problem. I prefer to "neutralize" these paths
    % by using very small alpha values wrt the rest of the values.
    alpha_p(alpha_p<=0) = min(abs(alpha_p))/1e6;
end

%
% CPLEX Output codes for MIP
%
% 101 
% CPXMIP_OPTIMAL 
% IloCplex::Optimal 
% Optimal integer solution found 
% 102 
% CPXMIP_OPTIMAL_TOL 
% IloCplex::OptimalTol 
% Optimal sol. within epgap or epagap tolerance found 
% 103 
% CPXMIP_INFEASIBLE 
% IloCplex::Infeasible 
% Integer infeasible 
% 104 
% CPXMIP_SOL_LIM 
% IloCplex::SolLim 
% Mixed integer solutions limit exceeded 
% 105 
% CPXMIP_NODE_LIM_FEAS 
% IloCplex::NodeLimFeas 
% Node limit exceeded, integer solution exists 
% 106 
% CPXMIP_NODE_LIM_INFEAS 
% IloCplex::NodeLimInfeas 
% Node limit exceeded, no integer solution 
% 107 
% CPXMIP_TIME_LIM_FEAS 
% IloCplex::AbortTimeLim 
% Time limit exceeded, integer solution exists 
% 108 
% CPXMIP_TIME_LIM_INFEAS 
% IloCplex::TimeLimInfeas 
% Time limit exceeded, no integer solution 
% 109 
% CPXMIP_FAIL_FEAS 
% IloCplex::FailFeas 
% Error termination, integer solution exists 
% 110 
% CPXMIP_FAIL_INFEAS 
% IloCplex::FailInfeas 
% Error termination, no integer solution 
% 111 
% CPXMIP_MEM_LIM_FEAS 
% IloCplex::MemLimFeas 
% Treememory limit, integer solution exists 
% 112 
% CPXMIP_MEM_LIM_INFEAS 
% IloCplex::MemLimInfeas 
% Treememory limit, no integer solution exists 
% 113 
% CPXMIP_ABORT_FEAS 
% IloCplex::AbortFeas 
% Aborted, integer solution exists 
% 114 
% CPXMIP_ABORT_INFEAS 
% IloCplex::AbortInfeas 
% Aborted, no integer solution 
% 115 
% CPXMIP_OPTIMAL_INFEAS 
% IloCplex::OptimalInfeas 
% Problem optimal with unscaled infeasibilities 
% 116 
% CPXMIP_FAIL_FEAS_NO_TREE 
% IloCplex::FailFeasNoTree 
% Out of memory, no tree, integer solution exists 
% 117 
% CPXMIP_FAIL_INFEAS_NO_TREE 
% IloCplex::FailInfeasNoTree 
% Out of memory, no tree, no integer solution 
% 118 
% CPXMIP_UNBOUNDED 
% IloCplex::Unbounded 
% Model has an Unbounded ray 
% 119 
% CPXMIP_INForUNBD 
% IloCplex::InfOrUnbd 
% Model is proved either Infeasible or Unbounded 
%

