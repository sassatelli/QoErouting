function [sol, dual, record] = maxQoE_DGLR(matNet, pathInfo, videoInfo, dmdVect_transport, param)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    tic
    L = size(pathInfo.bin_edgesInPath,1);
    D = size(dmdVect_transport,1);     

    %Retriveing edge capacities and delays
    if size(matNet.bwVect,1)==L
        capacity_e = matNet.bwVect;%kbps
    else
        capacity_e = [matNet.bwVect;matNet.bwVect];
    end
    dual.lambda_e = 1e-5*ones(L,1);% units: ratio btw QoE (0-1) and throughput (kbps)--> order of min lin_slope~ 1e-5
    stoppingCriterion = 0;
    step_length = 1e-10; % order_step_length = order_min_lambda / order_min_gradient(~10 Mbps) = 1e-5/1e+5 = 1e-10
    it = 0;
    record.dualObj = [];
    record.primalObj = [];
    record.gap = [];
    record.UB_QoE = [];
    record.UB_QoE_gap= [];
    record.excessCapacity = [];
    record.acceptanceRate = [];
    record.primalObj_dispersion = [];
    while(not(stoppingCriterion))
        %%%%%%%%%%% LAGRANGEAN RELAXED SUBPROBLEMS %%%%%%%%%%%
        [primal] = relaxedPrimalSubproblems_heur(matNet, pathInfo, videoInfo, dmdVect_transport, dual.lambda_e);
        sol = primal;

        %%%% DUAL GRADIENT UPDATE %%%%%%%%%%%
        dual.gradient_e = primal.linkLoad_e - capacity_e;% kbps      
        dual.lambda_e = max([dual.lambda_e+step_length*dual.gradient_e, zeros(L,1)],[],2); 
        
        %%%% UPDATE STOPPING CRITERION
        dual.obj = primal.QoE + sum(dual.lambda_e.*dual.gradient_e); %upper bound on primal solution
        dual.gap = sum(dual.lambda_e.*dual.gradient_e)/dual.obj; %dual.obj-primal.QoE;      
        dual.excessCapacity = sum(dual.gradient_e(dual.gradient_e>0)); 
        
        %%%% computing a feasible throughput %%%%
        linkLoad_e = primal.linkLoad_e';
        linkLoad_e(linkLoad_e==0)=1e-7;
        linkExcess_e = dual.gradient_e;
        linkExcess_e(dual.gradient_e<=0)=0;
        x_de_table = (primal.x_dp_table*pathInfo.bin_edgesInPath')./repmat(linkLoad_e,[D 1]);   
        excess_flow_d = max(x_de_table.*repmat(linkExcess_e',[D 1]),[],2);
        acceptRate_d = (primal.throughput_d-excess_flow_d)./primal.throughput_d;
        
        record.acceptanceRate = [record.acceptanceRate; sum(acceptRate_d)/D];
        
        record.primalObj = [record.primalObj primal.QoE ];
        record.dualObj = [record.dualObj dual.obj];
        dual.UB_QoE = min(record.dualObj); 
        dual.UB_QoE_gap = (dual.UB_QoE-primal.QoE)/dual.UB_QoE;
        
        record.gap = [record.gap dual.gap];
        record.UB_QoE = [record.UB_QoE dual.UB_QoE];
        record.UB_QoE_gap = [record.UB_QoE_gap dual.UB_QoE_gap];
        record.excessCapacity = [record.excessCapacity dual.excessCapacity];
                
        it = it+1;
        if it > param.min_iter,
            last_primalObj_vector = record.primalObj(end-param.no_improvement_iter:end);
            dual.primalObj_dispersion = (max(last_primalObj_vector)-min(last_primalObj_vector))/mean(last_primalObj_vector);
            record.primalObj_dispersion = [record.primalObj_dispersion dual.primalObj_dispersion];
            if  dual.primalObj_dispersion < param.no_improvement_thr, stoppingCriterion = 1; end
            if it > param.max_iter, stoppingCriterion = 1; end
        end
    end
    sol.time = toc;
    sol.num_iter = it;
end
% function feas = primal_feasible(matNet, pathInfo, videoInfo, dmdVect_transport, primal, dual)
%        %%%% computing a fesaible solution (LB) %%%%
%         linkLoad_e = primal.linkLoad_e';
%         linkLoad_e(linkLoad_e==0)=1e-7;
%         linkExcess_e = dual.gradient_e;
%         linkExcess_e(dual.gradient_e<=0)=0;
%         x_de_table = (primal.x_dp_table*pathInfo.bin_edgesInPath')./repmat(linkLoad_e,[D 1]);   
%         %sum(x_de_table,1)
%         excess_flow_d = max(x_de_table.*repmat(linkExcess_e',[D 1]),[],2);
%         acceptRate_d = (primal.throughput_d-excess_flow_d)./primal.throughput_d;
%         
%         feas.x_dp_table = primal.x_dp_table.*repmat(acceptRate_d,[1 P]);
%         feas.x_dp_opt = mat2vct(feas.x_dp_table);
%     
%         sol.QoE = sum(sol.u_d_opt);
%         
%         x_p = sum(feas.x_dp_table,1);
%         feas.linkLoad_e = (pathInfo.bin_edgesInPath*x_p');
%         feas.countPath_d = sum(sol.x_dp_table>1e-9,2);
%         feas.alpha_p = primal.alpha_p;
%         
%         pause
%         
% %     x_dp_opt    
%         pause
% 
% end
function [sol] = relaxedPrimalSubproblems_heur(matNet, pathInfo, videoInfo, dmdVect_transport, lambda_e) 

    L = size(pathInfo.bin_edgesInPath,1);
    N = size(pathInfo.bin_initNodes,1);
    P = size(pathInfo.bin_edgesInPath,2);
    D = size(dmdVect_transport,1);
    linkTable = matNet.e2ij(:,2:3);
    delay_e = matNet.delayVect;

    sol.QoE = 0;
    sol.x_dp_opt = sparse(1,D*P);
    sol.u_d_opt = zeros(D,1);
    sol.throughput_d = zeros(D,1);
    sol.x_dp_table = sparse(D,P);
    sol.linkLoad_e = zeros(L,1);
    
    lambda_p = lambda_e'*pathInfo.bin_edgesInPath; %path lamda
    alpha_p= computeAlpha(delay_e, pathInfo.bin_edgesInPath); %alpha lamda

    for d_id = 1:D
        src = dmdVect_transport(d_id,4);
        dst = dmdVect_transport(d_id,5);
        content = dmdVect_transport(d_id,6); %content type 
        resol = dmdVect_transport(d_id,7); % resolution 
        policy = dmdVect_transport(d_id,8); % HAS adaptation
        %ij = (src-1)*N + dst;
        minrate = videoInfo(content,resol,policy).minrate;
        maxrate = videoInfo(content,resol,policy).maxrate;
        bin_ind=videoInfo(content,resol,policy).pieces(:,1)|videoInfo(content,resol,policy).pieces(:,2);
        %lin_slope = nonzeros(videoInfo(content,resol,policy).pieces(:,1));
        %lin_y_intercept = nonzeros(videoInfo(content,resol,policy).pieces(:,2));
	lin_slope = videoInfo(content,resol,policy).pieces(logical(bin_ind),1);
        lin_y_intercept = videoInfo(content,resol,policy).pieces(logical(bin_ind),2);
        if not(numel(lin_slope)==numel(lin_y_intercept)), error('not(numel(lin_slope)==numel(lin_y_intercept))'); end

        [best_pathIDs, best_pathLambda, best_pathAlpha] = pathSelection_v2(src, dst, matNet, pathInfo, lambda_p, alpha_p);%best_path is sequence of nodes
        [x, y, QoE]= flowAllocation(minrate, maxrate, lin_slope, lin_y_intercept, best_pathLambda, best_pathAlpha);
        sol.x_dp_table(d_id, best_pathIDs) = x; 
        sol.u_d_opt(d_id) = QoE;  
        sol.throughput_d(d_id) = y;  
    end
    sol.x_dp_opt = mat2vct(sol.x_dp_table);
    sol.QoE = sum(sol.u_d_opt);
    x_p = sum(sol.x_dp_table,1);
    sol.linkLoad_e = (pathInfo.bin_edgesInPath*x_p');
    sol.countPath_d = sum(sol.x_dp_table>1e-9,2);
    sol.alpha_p = alpha_p;
end
function [x, y, QoE] = flowAllocation(minrate, maxrate, lin_slope, lin_y_intercept, best_pathLambda, best_pathAlpha)
%y: video throughput
%x: available bw
    ratio_lambda_alpha = best_pathLambda/best_pathAlpha;
    if ratio_lambda_alpha > lin_slope(1),
        y = minrate;
        x=y/best_pathAlpha;
        QoE = lin_slope(1)*y + lin_y_intercept(1);
        if QoE<0, 
            error('minrate');
        end
    elseif  lin_slope(end) > ratio_lambda_alpha,
        y = maxrate;
        QoE = lin_slope(end)*y + lin_y_intercept(end);
        if QoE<0, error('minrate');end
    else
        i = find(lin_slope > ratio_lambda_alpha, 1,'last');
        j = i+1;
        y = (lin_y_intercept(j)-lin_y_intercept(i))/(lin_slope(i)-lin_slope(j)); 
        QoE = lin_slope(j)*y + lin_y_intercept(j);
        if QoE<0, error('in the mideddle');end
    end
    x=y/best_pathAlpha;
end

function [best_pathIDs, best_pathLambda, best_pathAlpha] = pathSelection_v2(src, dst, matNet, pathInfo, lambda_p, alpha_p)

    N= matNet.nbNodes;
    ij = (src-1)*N + dst;
    pathIDs_forThisPair = find(pathInfo.bin_nodePairs(ij,:));
    %P_sd = numel(pathIDs_forThisPair);
    pathTable =[pathIDs_forThisPair' lambda_p(pathIDs_forThisPair)'./alpha_p(pathIDs_forThisPair)' lambda_p(pathIDs_forThisPair)' alpha_p(pathIDs_forThisPair)']; % num paths x 3
    sorted_pathTable = sortrows(pathTable,[2 -4]);
    best_pathIDs = sorted_pathTable(1,1);
    best_pathLambda = sorted_pathTable(1,3);
    best_pathAlpha = sorted_pathTable(1,4);
    if numel(best_pathIDs)>1, error('maxQoE_DGLR:sum(pathIDs_bestPath)>1'),end
    if numel(best_pathIDs)==0, error('maxQoE_DGLR:sum(pathIDs_bestPath)==0'),end
    %lambda_p = sum(pathInfo.bin_edgesInPath(:,pathIDs_forThisPair).*repmat(lambda_e, [1 P_sd]),1);
    %delay_p = sum(pathInfo.bin_edgesInPath(:,pathIDs_forThisPair).*repmat(delay_e, [1 P_sd]),1);
end

function [best_pathIDs, best_pathLambda, best_pathAlpha] = pathSelection(src, dst, matNet, pathInfo, lambda_e)
    N= matNet.nbNodes;
    linkTable = matNet.e2ij(:,2:3);
    
    lambdaMatrix = Inf(N,N);
    nodePairInds_in_matrix = sub2ind(size(lambdaMatrix),linkTable(:,2)',linkTable(:,1)');
    lambdaMatrix(nodePairInds_in_matrix)=lambda_e;
    
    delayMatrix = matNet.Delay;
    delayMatrix(delayMatrix==0) = Inf;

    minDelay  = 5; %ms
    maxDelay  = 65; %ms
    delayStep = 5; %ms
    rangeDelayThr = minDelay:delayStep:maxDelay;  
    best_path = [];
    best_pathLambda = Inf;
    best_pathAlpha = 0;
    min_lambda_alpha = Inf;
    for delayThr = rangeDelayThr,
        path = LARAC(src, dst, lambdaMatrix, delayMatrix, delayThr);         
        
        pathLambda = computePathCost(path, lambdaMatrix);
        pathAlpha  = computePathAlpha_mat(path, delayMatrix); 
        if pathLambda/pathAlpha <= min_lambda_alpha
            best_path = path;
            best_pathLambda = pathLambda;
            best_pathAlpha = pathAlpha;
            min_lambda_alpha = pathLambda/pathAlpha;
        end
    end
    bestPath_linkTable = [best_path(1:end-1)' best_path(2:end)'];
    bestPath_linkIds = find(ismember(linkTable,bestPath_linkTable,'rows'));      
    bin_edgesInBestPath = sparse(bestPath_linkIds,ones(1,length(bestPath_linkIds)),ones(1,length(bestPath_linkIds)),L,1);        
    best_pathIDs = ismember(pathInfo.bin_edgesInPath',bin_edgesInBestPath','rows');
    if sum(best_pathIDs)>1, error('maxQoE_DGLR:sum(pathIDs_bestPath)>1'),end
    if sum(best_pathIDs)==0, error('maxQoE_DGLR:sum(pathIDs_bestPath)==0'),end
end
function [path] = LARAC(src, dst, costMatrix, delayMatrix, delayThr)
    
    [minCostPath, minCost] = dijkstra(costMatrix, src, dst);
    delay_minCostPath = computePathCost(minCostPath, delayMatrix);
    if delay_minCostPath <= delayThr, path = minCostPath; return; end 
    
    [minDelayPath, minDelay] = dijkstra(delayMatrix, src, dst);
    cost_minDelayPath = computePathCost(minDelayPath, costMatrix);
    if minDelay > delayThr, path = []; return; end % There is no solution

    while (1)
        lambda = (minCost - cost_minDelayPath)/(minDelay - delay_minCostPath);
        costMatrix_lambda = costMatrix + lambda*delayMatrix;
        
        [minCostPath_lambda, minCost_lambda] = dijkstra(costMatrix_lambda, src, dst);
        cost_lambda_minCostPath = computePathCost(minCostPath, costMatrix_lambda);
        delay_minCostPath_lambda = computePathCost(minCostPath_lambda, delayMatrix);
        
        if (minCostPath_lambda == cost_lambda_minCostPath)
            path = minDelayPath;
            break
        else
            if delay_minCostPath_lambda <= delayThr
                minDelayPath = minCostPath_lambda;
                cost_minDelayPath = computePathCost(minDelayPath, costMatrix);
                minDelay = computePathCost(minDelayPath, delayMatrix);
            else
                minCostPath = minCostPath_lambda;
                minCost = computePathCost(minCostPath, costMatrix);
                delay_minCostPath = computePathCost(minCostPath, delayMatrix);
            end
        end 
    end
end
function pathCost = computePathCost(path, costMatrix)
    linkTable = [path(1:end-1)' path(2:end)'];
    nodePairInds_in_matrix = sub2ind(size(costMatrix),linkTable(:,2)',linkTable(:,1)');
    pathCost = sum(costMatrix(nodePairInds_in_matrix));
end
function alpha_p= computeAlpha(delay_e, bin_edgesInPath)
    %load('cubic/cubicThrp_vs_delay','avg_coeffs') it's for the range
    % 20-180ms
    % delay in ms
    avg_coeffs_cubicThrp_vs_delay = [-0.00127870740156237,1.00108375856055]; %slope, y-intercept
    thrp_vs_delay_slope = avg_coeffs_cubicThrp_vs_delay(1);
    thrp_vs_delay_y_intcpt = avg_coeffs_cubicThrp_vs_delay(2);      
    delay_p = delay_e'*bin_edgesInPath; %path delay
    alpha_p = (thrp_vs_delay_y_intcpt + thrp_vs_delay_slope*delay_p);
    
    %negative alphas_p do not make sense. Ideally, their associated paths
    % should be removed from the problem. I prefer to "neutralize" these paths
    % by using very small alpha values wrt the rest of the values.
    alpha_p(alpha_p<=0) = min(abs(alpha_p))/1e6;
end
function pathAlpha= computePathAlpha_mat(path, delayMatrix)
    linkTable = [path(1:end-1)' path(2:end)'];
    nodePairInds_in_matrix = sub2ind(size(delayMatrix),linkTable(:,2)',linkTable(:,1)');
    pathDelay = sum(delayMatrix(nodePairInds_in_matrix)); %path delay
    
    %load('cubic/cubicThrp_vs_delay','avg_coeffs') it's for the range
    % 20-180ms
    % delay in ms
    avg_coeffs_cubicThrp_vs_delay = [-0.00127870740156237,1.00108375856055]; %slope, y-intercept
    thrp_vs_delay_slope = avg_coeffs_cubicThrp_vs_delay(1);
    thrp_vs_delay_y_intcpt = avg_coeffs_cubicThrp_vs_delay(2);      
    pathAlpha = (thrp_vs_delay_y_intcpt + thrp_vs_delay_slope*pathDelay);
    
    %negative alphas_p do not make sense. Ideally, their associated paths
    % should be removed from the problem. I prefer to "neutralize" these paths
    % by using very small alpha values wrt the rest of the values.
    pathAlpha(pathAlpha<=0) = 0;
end
function vector_col = mat2vct(matrix)
    vector_col = reshape(matrix', [numel(matrix) 1]);
end
function matrix = vct2mat(vector, numRows, numCols)
    matrix = (reshape(vector,[numCols numRows]))';
end
