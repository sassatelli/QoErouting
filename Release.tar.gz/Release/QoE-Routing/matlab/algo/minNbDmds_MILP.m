function [sol] = minNbDmds_MILP(matNet, pathInfo, videoInfo, dmdVect_transport)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    tic;
    % Variables are [x_dp, gamma, delta], with this index order (see report)
    L = size(pathInfo.bin_edgesInPath,1);
    N = size(pathInfo.bin_initNodes,1);
    P = size(pathInfo.bin_edgesInPath,2);
    D = size(dmdVect_transport,1);
    
    %%%% WARNING UNITS %%%% 
    % Retriveing edge capacities and delays
    if (size(matNet.bwVect,1) == L)
        capacity_e = ones(size(matNet.bwVect,1),1); % matNet.bwVect; % kbps
    else
        capacity_e = ones(2*size(matNet.bwVect,1),1);%[matNet.bwVect; matNet.bwVect];
    end
    
    A_path_ctr = sparse(D,D*P+1); % #dmds x #dmds*#paths + gamma
    A_cap_ctr  = sparse(L,D*P+1); % #links x #dmds*#paths + gamma
    
    for d_id = 1:D
        src = dmdVect_transport(d_id,4);
        dst = dmdVect_transport(d_id,5);
        ij = (src-1)*N + dst;
        
        A_path_ctr(d_id, ((d_id-1)*P + find(pathInfo.bin_nodePairs(ij,:)))) = 1;
        A_cap_ctr(:,(d_id-1)*P+1 : (d_id-1)*P+P) = kron(ones(L,1),pathInfo.bin_nodePairs(ij,:)) .* pathInfo.bin_edgesInPath; 
    end
    A_cap_ctr(1:L,D*P+1) = -capacity_e;
    
    A = [A_cap_ctr;
         A_path_ctr];
    
	ctype_x_dp  = repmat('B', 1, D*P);
    ctype_gamma = repmat('C', 1, 1);
    
    obj = [sparse(D*P,1); 1]; % gamma = max number of demands passig over a link
    
    ub = [ones(D*P,1); Inf];
    lb = zeros(D*P+1,1);
    
    lhs = [-Inf*ones(L,1);
           ones(D,1);
          ];
    rhs = [zeros(L,1);
           ones(D,1);
          ];
    
    cplex = Cplex('NbDmds');
    cplex.Model.sense = 'minimize';
    cplex.Model.obj   = obj;
    cplex.Model.lb    = lb;
    cplex.Model.ub    = ub;
    cplex.Model.A     = A;
    cplex.Model.lhs   = full(lhs);
    cplex.Model.rhs   = full(rhs);
    cplex.Model.ctype = [ctype_x_dp, ctype_gamma];
    [cplex_opt_gap, cplex_time_limit] = read_opt_gap();
    cplex.Param.mip.tolerances.mipgap.Cur = cplex_opt_gap;
    cplex.Param.timelimit.Cur = cplex_time_limit;
    
    cplex.solve();
    
    sol.status = cplex.Solution.status;
    sol.statusstring = cplex.Solution.statusstring;
    sol.time = toc;
    sol.cplex_time = cplex.Solution.time;
    if ((sol.status == 101) || (sol.status == 102))
        % Feasible and optimal solution
        sol.MLU = cplex.Solution.objval;
        for d_id = 1:D
            src = dmdVect_transport(d_id,4);
            dst = dmdVect_transport(d_id,5);
            content    = dmdVect_transport(d_id,6); % content type 
            resolution = dmdVect_transport(d_id,7); % resolution 
            policy     = dmdVect_transport(d_id,8); % HAS adaptation
            ij = (src-1)*N + dst;
            cplex.Solution.x(1:(d_id-1)*P+1 : (d_id-1)*P+P) = cplex.Solution.x(1:(d_id-1)*P+1 : (d_id-1)*P+P);
        end
        sol.x_dp_opt  = cplex.Solution.x(1:D*P);
        sol.gamma_opt = cplex.Solution.x(D*P+1);
        sol.linkLoad_e = A(1:L,:)*cplex.Solution.x;
        sol.x_dp_table = vct2mat(sol.x_dp_opt,D,P);
        sol.countPath_d = sum(sol.x_dp_table>1e-9,2);
    end
    
    
end

function vector_col = mat2vct(matrix)
    vector_col = reshape(matrix', [numel(matrix) 1]);
end

function matrix = vct2mat(vector, numRows, numCols)
    matrix = (reshape(vector,[numCols numRows]))';
end
