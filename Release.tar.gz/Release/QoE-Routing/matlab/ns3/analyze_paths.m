function analyze_paths(file_instance, file_paths_1, file_paths_2)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


ns_initialize();
% Load network instance
load(file_instance);
% Load shortest paths (admission)
sp = load(file_paths_1);
% Load optimal paths (reoptimization)
opt = load(file_paths_2);

% Number of equal paths
nb_eq_paths = 0;
for d_sp=1:size(sp.routes_by_links,1)
    d_sp_i = sp.routes_by_links{d_sp,1};
    d_opt = 1;
    while (d_opt <= size(opt.routes_by_links,1))
        if (opt.routes_by_links{d_opt,1} == d_sp_i)
            break
        end
        d_opt = d_opt + 1;
    end
    if (d_opt > size(opt.routes_by_links,1))
        disp(['Error in analyze_paths(). Demand ', num2str(d_sp_i), ' [not found in file ', file_paths_2]);
        exit(-1);
    end
    %d_opt_i = opt.routes_by_links{d_opt,1};
    nb_eq_paths = nb_eq_paths + equal_paths(sp.routes_by_links{d_sp,2}, opt.routes_by_links{d_opt,2});
    
end

disp('*** STATS ***');
disp(['Number of equal paths: ', num2str(nb_eq_paths)]);

% Number of demands for each link
sp_link_dmd  = nb_dmds_on_links(matBackbone, sp.routes_by_links);
opt_link_dmd = nb_dmds_on_links(matBackbone, opt.routes_by_links);
sp_used_links  = full(sum(sp_link_dmd,2));
opt_used_links = full(sum(opt_link_dmd,2));
bar([sp_used_links, opt_used_links]);

end


function eq_paths = equal_paths(path_1, path_2)
    
    eq_paths = 0;
    if (size(path_1,1) > size(path_2,1))
        eq_paths = 0;
    else
        % Check link by link
        for i=1:size(path_1,1)
            if (path_1(i,1) ~= path_2(i,1))
                eq_paths = 0;
                return
            else
                eq_paths = 1;
            end
        end
        
    end
    
end

function link_dmd = nb_dmds_on_links(matNet, routes_by_links)

    link_dmd = sparse(matNet.nbEdges, matNet.nbDmds);
    for d=1:size(routes_by_links,1)
        d_i = routes_by_links{d,1};
        link_ids = routes_by_links{d,2};
        % Demand d_i uses links link_ids
        link_dmd(link_ids, d_i) = link_dmd(link_ids, d_i) + 1;
    end
    
end

