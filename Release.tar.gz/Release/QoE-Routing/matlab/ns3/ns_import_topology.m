function matNet = ns_import_topology()

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


formatAdjMat = '%f%f%f%f%f%f';
T = readtable('adj_matrix', 'Delimiter', ' ', 'Format', formatAdjMat);
num_nodes = max([T.x_source_(:); T.destination_(:)]) + 1;
matNet.Nodes = [0:num_nodes-1]';
matNet.Adj   = sparse(num_nodes, num_nodes);
matNet.Bw    = matNet.Adj;
matNet.Delay = matNet.Adj;
matNet.Ploss = matNet.Adj;
matNet.Buf   = matNet.Adj;
for i=1:numel(T.x_source_)
    matNet.Adj(T.x_source_(i) + 1, T.destination_(i) + 1)   = 1;
    matNet.Bw(T.x_source_(i) + 1, T.destination_(i) + 1)    = T.rate_bps_(i);
    matNet.Delay(T.x_source_(i) + 1, T.destination_(i) + 1) = T.delay_ms_(i);
    matNet.Ploss(T.x_source_(i) + 1, T.destination_(i) + 1) = T.pkt_loss_(i);
    matNet.Buf(T.x_source_(i) + 1, T.destination_(i) + 1)   = T.buffersize_pkts(i);
end

end
