function write_demands_toadmit(matNet, d)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


formatAdjMat = '%d %d %d %f %f %d %d %d\n';

% Video IDs
contentType(1,1) = 4;
contentType(2,1) = 5;
contentType(3,1) = 6;
% Resolution: 640�360 (360p), 1280�720 (720p), and 1920x1080 (1080p)
screenResolutionWH(1,:) = [640, 360];
screenResolutionWH(2,:) = [1280, 720];
screenResolutionWH(3,:) = [1920, 1080];

NS_SCENARIO = getenv('NS_SCENARIO');
filename = sprintf('%s/requests_toadmit', NS_SCENARIO);
fileID = fopen(filename, 'w');
fprintf(fileID, '#id, client, server, startsAt, stopsAt, videoId, screenWidth, screenHeight\n');
client = matNet.dmdClients(d,1);
server = matNet.dmdServers(d,1);
fprintf(fileID, formatAdjMat, matNet.Dmds(d,1), matNet.NodeID(client,1), matNet.NodeID(server,1), matNet.Dmds(d,2), matNet.Dmds(d,3), contentType(matNet.Dmds(d,6),1), screenResolutionWH(matNet.Dmds(d,7),1), screenResolutionWH(matNet.Dmds(d,7),2));
fclose(fileID);

end
