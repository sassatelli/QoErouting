function ns_plot_active_dmds(dmdVect)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                   QoE-aware Routing Computation                  %%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%                                                                    %
%% Code for solving the QoE-aware routing problem as the              %
%% network evolves. The code can be called by ns3 to admit            %
%% a new demand, reconfigure the network according to its status and  %
%% the QoE experiend by e2e connections [1].                          %
%%                                                                    %
%% Created by                                                         %
%% - Paris Reseach Center, Huawei Technologies Co. Ltd.               %
%% - Laboratoire d'Informatique, Signaux et Systèmes de               %
%%   Sophia Antipolis (I3S) Universite Cote d'Azur and CNRS           %
%%                                                                    %
%% Contributors:                                                      %
%% - Giacomo CALVIGIONI (I3S)                                         %
%% - Ramon APARICIO-PARDO (I3S)                                       %
%% - Lucile SASSATELLI (I3S)                                          %
%% - Jeremie LEGUAY (Huawei)                                          %
%% - Stefano PARIS (Huawei)                                           %
%% - Paolo MEDAGLIANI (Huawei)                                        %
%%                                                                    %
%% References:                                                        %
%% [1] Giacomo Calvigioni, Ramon Aparicio-Pardo, Lucile Sassatelli,   %
%%     Jeremie Leguay, Stefano Paris, Paolo Medagliani,               %
%%     "Quality of Experience-based Routing of Video Traffic for      %
%%      Overlay and ISP Networks". In the Proceedings of the IEEE     %
%%     International Conference on Computer Communications            %
%%      (INFOCOM), 15-19 April 2018.                                  %
%%                                                                    %
%% Contacts:                                                          %
%% - For any question please use the address: qoerouting@gmail.com    %
%%                                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


start_time = min(dmdVect(:,2));
end_time   = max(dmdVect(:,3));

events = sort([dmdVect(:,2); dmdVect(:,3)]);
nbActiveDmds = [];
for e=1:size(events,1)
    t = events(e,1);
    startedDmds  = find(dmdVect(:,2) <= t);
    notendedDmds = find(dmdVect(:,3) >= t);
    activeDmds = intersect(startedDmds, notendedDmds);
    nbActiveDmds = [nbActiveDmds; [t, size(activeDmds,1)]];
end

p_50 = prctile(nbActiveDmds(:,2), 50);
nbActiveDmds_top50 = nbActiveDmds((nbActiveDmds(:,2) >= p_50), :);

figure
hold 'on'
plot(nbActiveDmds(:,1), nbActiveDmds(:,2));
%plot(nbActiveDmds_top50(:,1), nbActiveDmds_top50(:,2));

end

