window.libdashSettings = {
  "credentials": {
    "key": "YOUR-KEY-HERE"
  },
  "cdnPath": "https://bitmovin-a.akamaihd.net/bitdash/latest/bitdash.min.js"
};